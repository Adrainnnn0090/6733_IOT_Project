//
//  DC6733Tests.swift
//  DC6733Tests
//
//  Created by Jo on 2025/7/15.
//

import Testing
@testable import DC6733

struct DC6733Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
