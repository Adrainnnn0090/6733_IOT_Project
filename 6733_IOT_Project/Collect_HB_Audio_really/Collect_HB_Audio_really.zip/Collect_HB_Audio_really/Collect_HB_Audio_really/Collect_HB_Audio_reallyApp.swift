//
//  Collect_HB_Audio_reallyApp.swift
//  Collect_HB_Audio_really
//
//  Created by adrian on 2025/7/15.
//

import SwiftUI

@main
struct Collect_HB_Audio_reallyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
