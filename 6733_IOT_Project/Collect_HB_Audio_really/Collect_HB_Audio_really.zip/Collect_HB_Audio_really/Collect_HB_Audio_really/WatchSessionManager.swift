//
//  WatchSessionManager.swift
//  Collect_HB_Audio_really
//
//  Created by adrian on 2025/7/15.
//
import Foundation
import WatchConnectivity

class WatchSessionManager: NSObject, WCSessionDelegate, ObservableObject {
    @Published var heartRate: Double?

    override init() {
        super.init()
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        print("✅ WCSession activated: \(activationState)")
    }

    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
            if let bpm = message["heartRate"] as? Double {
                print("📲 Received heart rate: \(bpm)")
                self.heartRate = bpm
            }
        }
    }

    // ✅ 必须实现的两个方法
    func sessionDidBecomeInactive(_ session: WCSession) {}
    
    func sessionDidDeactivate(_ session: WCSession) {
        WCSession.default.activate() // 重新激活
    }
}
