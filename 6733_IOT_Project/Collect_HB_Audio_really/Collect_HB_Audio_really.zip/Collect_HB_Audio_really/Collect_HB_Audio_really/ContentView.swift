//
//  ContentView.swift
//  Collect_HB_Audio_really
//
//  Created by adrian on 2025/7/15.
//

import SwiftUI

struct ContentView: View {
    @StateObject var watchSession = WatchSessionManager()

    var body: some View {
        VStack(spacing: 20) {
            Text("📱 ontime heart rate：")
            if let bpm = watchSession.heartRate {
                Text(String(format: "%.0f bpm", bpm))
                    .font(.largeTitle)
                    .bold()
            } else {
                Text("wating...")
            }
        }
        .padding()
    }
}
