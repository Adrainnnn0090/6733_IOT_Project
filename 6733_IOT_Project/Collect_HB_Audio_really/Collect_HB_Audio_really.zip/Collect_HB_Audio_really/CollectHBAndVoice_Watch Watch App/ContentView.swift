//
//  ContentView.swift
//  CollectHBAndVoice_Watch Watch App
//
//  Created by adrian on 2025/7/15.
//

import SwiftUI

struct ContentView: View {
    @StateObject var hrManager = HeartRateManager()

    var body: some View {
        VStack {
            Text("⌚️ Monitoring your Heart Beats...")
            Button("Start Workout") {
                hrManager.startWorkout()
            }
        }
    }
}
