//
//  CollectHBAndVoice_WatchApp.swift
//  CollectHBAndVoice_Watch Watch App
//
//  Created by adrian on 2025/7/15.
//

import SwiftUI

@main
struct CollectHBAndVoice_Watch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
