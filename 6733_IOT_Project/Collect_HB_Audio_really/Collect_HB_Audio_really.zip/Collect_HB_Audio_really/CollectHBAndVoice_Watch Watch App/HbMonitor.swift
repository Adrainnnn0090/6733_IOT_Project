import Foundation
import HealthKit
import WatchConnectivity

class HeartRateManager: NSObject, ObservableObject, HKLiveWorkoutBuilderDelegate, HKWorkoutSessionDelegate {
    private let healthStore = HKHealthStore()
    private var session: HKWorkoutSession?
    private var builder: HKLiveWorkoutBuilder?

    override init() {
        super.init()
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }

    func startWorkout() {
        let config = HKWorkoutConfiguration()
        config.activityType = .other
        config.locationType = .indoor

        do {
            session = try HKWorkoutSession(healthStore: healthStore, configuration: config)
            builder = session?.associatedWorkoutBuilder()

            builder?.dataSource = HKLiveWorkoutDataSource(healthStore: healthStore, workoutConfiguration: config)
            builder?.delegate = self
            session?.delegate = self

            session?.startActivity(with: Date())
            builder?.beginCollection(withStart: Date(), completion: { _, _ in })
        } catch {
            print("❌ Workout start error:", error)
        }
    }

    func workoutBuilder(_ builder: HKLiveWorkoutBuilder, didCollectDataOf collectedTypes: Set<HKSampleType>) {
        let heartRateType = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        guard collectedTypes.contains(heartRateType) else { return }

        if let hr = builder.statistics(for: heartRateType)?.mostRecentQuantity() {
            let bpm = hr.doubleValue(for: HKUnit(from: "count/min"))
            print("❤️ Heart Rate: \(bpm)")
            sendToPhone(bpm)
        }
    }

    private func sendToPhone(_ bpm: Double) {
        if WCSession.default.isReachable {
            WCSession.default.sendMessage(["heartRate": bpm], replyHandler: nil, errorHandler: nil)
        }
    }

    // 不需要处理这两个也没事
    func workoutBuilderDidCollectEvent(_ builder: HKLiveWorkoutBuilder) {}
    func workoutSession(_ session: HKWorkoutSession, didChangeTo toState: HKWorkoutSessionState, from fromState: HKWorkoutSessionState, date: Date) {}
    func workoutSession(_ session: HKWorkoutSession, didFailWithError error: Error) {}
}

extension HeartRateManager: WCSessionDelegate {
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
}
