//
//  CollectHBAndVoice_Watch_Watch_AppTests.swift
//  CollectHBAndVoice_Watch Watch AppTests
//
//  Created by adrian on 2025/7/15.
//

import Testing
@testable import CollectHBAndVoice_Watch_Watch_App

struct CollectHBAndVoice_Watch_Watch_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
