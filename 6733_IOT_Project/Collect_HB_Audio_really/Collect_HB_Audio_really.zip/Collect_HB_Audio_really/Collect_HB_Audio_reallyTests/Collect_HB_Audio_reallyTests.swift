//
//  Collect_HB_Audio_reallyTests.swift
//  Collect_HB_Audio_reallyTests
//
//  Created by adrian on 2025/7/15.
//

import Testing
@testable import Collect_HB_Audio_really

struct Collect_HB_Audio_reallyTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
